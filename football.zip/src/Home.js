import React from 'react'
import './App.css';
//import { Carousel } from 'react-responsive-carousel';
import 'react-responsive-carousel/lib/styles/carousel.min.css';
import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Carousel, Row, Col } from 'antd';
import { PlayCircleOutlined } from '@ant-design/icons';

const Home = () => {
    const [match, setMatch] = useState(null);
    const API_KEY = 'e1b28aeb564f4851abae6d5ecaa29beb'; // Replace with your API key
    // Get the current date
    let currentDate = new Date();
    // Calculate the start date (5 days before today)
    let startDate = new Date(currentDate.getTime() - 5 * 24 * 60 * 60 * 1000).toISOString().slice(0, 10);
    // Calculate the end date (5 days after today)
    let endDate = new Date(currentDate.getTime() + 5 * 24 * 60 * 60 * 1000).toISOString().slice(0, 10);
    // Construct the API request URL
    let URL = `http://localhost:3001/http://api.football-data.org/v4/matches?competitions=CL,PD,PL,BL1,SA,FL1&dateFrom=${startDate}&dateTo=${endDate}`;

    useEffect(() => {
        fetch(URL, {
            method: 'GET',
            headers: {
                'X-Auth-Token': API_KEY,
                'Content-Type': 'application/json'
            },
            mode: 'cors'
        })
            .then(response => response.json())
            .then(data => {
                const matches = data.matches;
                if (matches.length > 0) {
                    const match = matches[0];
                    const utcDate = new Date(match.utcDate);
                    const indianDate = utcDate.toLocaleString('en-IN', {
                        timeZone: 'Asia/Kolkata',
                        day: 'numeric',
                        month: 'short',
                        year: 'numeric',
                        hour: 'numeric',
                        minute: 'numeric'
                    });
                    match.indianDate = indianDate;
                    setMatch(match);
                }
            })
            .catch(error => console.error(error));
    }, []);


    //for news api calling 

    const [newsData, setNewsData] = useState([]);
    const API_KEYY = '6d80ae95-4398-420d-870b-ad0c8f0f6b84';
    const currentPage = 1;

    const fetchNewsData = async () => {
        try {
            const response = await fetch(
                `https://content.guardianapis.com/search?api-key=${API_KEYY}&q=football&section=football&tag=football/football&show-fields=all&order-by=newest&lang=en&edition=uk,fr,de,es,it&page=${currentPage}`
            );
            const data = await response.json();
            const results = data.response.results.slice(0, 3); // Retrieve only the first three results
            setNewsData(results);
        } catch (error) {
            console.log('Error fetching news data:', error);
        }
    };

    useEffect(() => {
        fetchNewsData();
    }, []);
    const formatDate = (dateString) => {
        const options = { year: 'numeric', month: 'long', day: 'numeric' };
        return new Date(dateString).toLocaleDateString('en-US', options);
    };
    console.log(newsData);

    //for next match
    const [nextMatch, setNextMatch] = useState(null);
    const API_KEYYY = 'e1b28aeb564f4851abae6d5ecaa29beb'; // Replace with your API key
    let currentDatee = new Date();
    let startDatee = new Date(currentDatee.getTime() - 0 * 24 * 60 * 60 * 1000).toISOString().slice(0, 10);
    let endDatee = new Date(currentDatee.getTime() + 10 * 24 * 60 * 60 * 1000).toISOString().slice(0, 10);
    let URLL = `http://localhost:3001/http://api.football-data.org/v4/matches?competitions=CL,PD,PL,BL1,SA,FL1&dateFrom=${startDatee}&dateTo=${endDatee}`;

    useEffect(() => {
        fetchNextMatch();
    }, []);

    const fetchNextMatch = () => {
        fetch(URLL, {
            method: 'GET',
            headers: {
                'X-Auth-Token': API_KEYYY,
                'Content-Type': 'application/json'
            },
            mode: 'cors'
        })
            .then(response => response.json())
            .then(data => {
                const matches = data.matches;
                if (matches.length > 0) {
                    const nextMatch = matches[0];
                    const utcDate = new Date(nextMatch.utcDate);
                    const indianDate = utcDate.toLocaleString('en-IN', {
                        timeZone: 'Asia/Kolkata',
                        day: 'numeric',
                        month: 'short',
                        year: 'numeric',
                        hour: 'numeric',
                        minute: 'numeric'
                    });
                    nextMatch.indianDate = indianDate;
                    setNextMatch(nextMatch);
                }
            })
            .catch(error => console.error(error));
    };

    //for video slider 
    const [videos, setVideos] = useState([]);
    const [isLoading, setIsLoading] = useState(false);

    const fetchVideos = () => {
        setIsLoading(true);

        fetch(
            `https://www.scorebat.com/video-api/v3/feed/?token=ODg2ODZfMTY4NDc0MjEyNl84MTVhNzk1MDBjN2RkYjk4MDU1ODhiZjk5MzUyZWFjOTUwOTYxZjJm`
        )
            .then(response => response.json())
            .then(data => {
                const firstThreeVideos = data.response.slice(0, 3).map(video => {
                    const videoUrl = video.videos[0].embed.match(/src='([^']+)'/)[1];
                    const date = new Date(video.date);
                    const formattedDate = `${date.getDate()} ${getMonthName(
                        date.getMonth()
                    )} ${date.getFullYear()} ${formatTime(
                        date.getHours(),
                        date.getMinutes()
                    )}`;
                    return { ...video, videoUrl, formattedDate };
                });

                setVideos(firstThreeVideos);
                setIsLoading(false);
            })
            .catch(error => {
                console.error(error);
                setIsLoading(false);
            });
    };

    useEffect(() => {
        fetchVideos();
    }, []);

    const getMonthName = month => {
        const months = [
            'January',
            'February',
            'March',
            'April',
            'May',
            'June',
            'July',
            'August',
            'September',
            'October',
            'November',
            'December'
        ];
        return months[month];
    };

    const formatTime = (hours, minutes) => {
        const formattedHours = hours.toString().padStart(2, '0');
        const formattedMinutes = minutes.toString().padStart(2, '0');
        return `${formattedHours}:${formattedMinutes}`;
    };

    return (
        <div>
            <div class="site-wrap">

                <div class="site-mobile-menu site-navbar-target">
                    <div class="site-mobile-menu-header">
                        <div class="site-mobile-menu-close">
                            <span class="icon-close2 js-menu-toggle"></span>
                        </div>
                    </div>
                    <div class="site-mobile-menu-body"></div>
                </div>


                <header className="site-navbar py-4" role="banner">
                    <div className="container">
                        <div className="d-flex align-items-center">
                            <div className="site-logo">
                                <a href="index.html">
                                    <img src="https://i.ibb.co/rFTrxDL/logo.png" alt="Logo" />
                                </a>
                            </div>
                            <div className="ml-auto">
                                <nav className="site-navigation position-relative text-right" role="navigation">
                                    <ul className="site-menu main-menu js-clone-nav mr-auto">
                                        <li className="active" style={{ color: 'white', width: 'calc(100% / 5)' }}><a>Home</a></li>
                                        <Link to="/matches" style={{ color: 'white', width: 'calc(100% / 5)' }}><li style={{ listStyle: 'none' }}><a className="nav-link">Matches</a></li></Link>
                                        <Link to="/players" style={{ color: 'white', width: 'calc(100% / 5)' }}><li style={{ listStyle: 'none' }}><a className="nav-link">Players</a></li></Link>
                                        <Link to="/news" style={{ color: 'white', width: 'calc(100% / 5)' }}><li style={{ listStyle: 'none' }}><a className="nav-link">News</a></li></Link>
                                        <Link to="/highlights" style={{ color: 'white', width: 'calc(100% / 5)' }}><li style={{ listStyle: 'none' }}><a className="nav-link">Highlights</a></li></Link>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                    </div>
                </header>


                <div className="hero overlay" style={{ backgroundImage: "url('https://i.ibb.co/5rhf0LL/bg-3.jpg')" }}>
                    <div className="container">
                        <div className="row align-items-center">
                            <div className="col-lg-5 ml-auto">
                                <h1 className="text-white">World Cup Event</h1>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Soluta, molestias repudiandae pariatur.</p>
                                <div id="date-countdown"></div>
                                <p>
                                    <a href="#" className="btn btn-primary py-3 px-4 mr-3">Book Ticket</a>
                                    <a href="#" className="more light">Learn More</a>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>




                <div className="container">
                    <div className="row">
                        <div className="col-lg-12">
                            {match && (
                                <div className="d-flex team-vs">
                                    <span className="score">{match.score.fullTime.home}-{match.score.fullTime.away}</span>
                                    <div className="team-1 w-50">
                                        <div className="team-details w-100 text-center">
                                            <img src={match.homeTeam.crest} alt="Image" className="img-fluid" />
                                            <h3>{match.homeTeam.name}</h3>
                                            <ul className="list-unstyled">
                                                {match?.homeTeamEvents?.map((event, index) => (
                                                    <li key={index}>{event.player.name} ({event.minute})</li>
                                                ))}
                                            </ul>
                                        </div>
                                    </div>
                                    <div className="team-2 w-50">
                                        <div className="team-details w-100 text-center">
                                            <img src={match.awayTeam.crest} alt="Image" className="img-fluid" />
                                            <h3>{match.awayTeam.name}</h3>
                                            <ul className="list-unstyled">
                                                {match?.awayTeamEvents?.map((event, index) => (
                                                    <li key={index}>{event.player.name} ({event.minute})</li>
                                                ))}
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            )}
                        </div>
                    </div>
                </div>

                <div className="latest-news">
                    <div className="container">
                        <div className="row">
                            <div className="col-12 title-section">
                                <h2 className="heading">Latest News</h2>
                            </div>
                        </div>
                        <div className="row no-gutters">
                            {newsData.map((news, index) => (
                                <div className="col-md-4" key={index}>
                                    <div className="post-entry">
                                        <a href="#">
                                            <img src={news.fields.thumbnail} alt="Image" className="img-fluid" />
                                        </a>
                                        <div className="caption">
                                            <div className="caption-inner">
                                                <h3 className="mb-3">{news.webTitle}</h3>
                                                <div className="author d-flex align-items-center">
                                                    <div className="img mb-2 mr-3">
                                                        <img src="images/person_1.jpg" alt="" />
                                                    </div>
                                                    <div className="text">
                                                        <h4>{news.fields.byline}</h4>
                                                        <span>{formatDate(news.webPublicationDate)} | Sports</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>

                <div class="site-section bg-dark">
                    <div class="container">
                        <div class="row">
                            <div className="col-lg-6">
                                <div className="widget-next-match">
                                    <div className="widget-title">
                                        <h3>Next Match</h3>
                                    </div>
                                    <div className="widget-body mb-3">
                                        <div className="widget-vs">
                                            {nextMatch ? (
                                                <div className="d-flex align-items-center justify-content-around justify-content-between w-100">
                                                    <div className="team-1 text-center">
                                                        <img src={nextMatch.homeTeam.crest} alt="Image" />
                                                        <h3>{nextMatch.homeTeam.name}</h3>
                                                    </div>
                                                    <div>
                                                        <span className="vs"><span>VS</span></span>
                                                    </div>
                                                    <div className="team-2 text-center">
                                                        <img src={nextMatch.awayTeam.crest} alt="Image" />
                                                        <h3>{nextMatch.awayTeam.name}</h3>
                                                    </div>
                                                </div>
                                            ) : (
                                                <p>Loading next match...</p>
                                            )}
                                        </div>
                                    </div>
                                    {nextMatch && (
                                        <div className="text-center widget-vs-contents mb-4">
                                            <h4>{nextMatch.competition.name}</h4>
                                            <p className="mb-5">
                                                <span className="d-block">{nextMatch.indianDate}</span>

                                                <strong className="text-primary">{nextMatch.venue}</strong>
                                            </p>
                                            <div id="date-countdown2" className="pb-1"></div>
                                        </div>
                                    )}
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="widget-next-match">
                                    <table class="table custom-table">
                                        <thead>
                                            <tr>
                                                <th>P</th>
                                                <th>Team</th>
                                                <th>W</th>
                                                <th>D</th>
                                                <th>L</th>
                                                <th>PTS</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>1</td>
                                                <td><strong class="text-white">Football League</strong></td>
                                                <td>22</td>
                                                <td>3</td>
                                                <td>2</td>
                                                <td>140</td>
                                            </tr>
                                            <tr>
                                                <td>2</td>
                                                <td><strong class="text-white">Soccer</strong></td>
                                                <td>22</td>
                                                <td>3</td>
                                                <td>2</td>
                                                <td>140</td>
                                            </tr>
                                            <tr>
                                                <td>3</td>
                                                <td><strong class="text-white">Juvendo</strong></td>
                                                <td>22</td>
                                                <td>3</td>
                                                <td>2</td>
                                                <td>140</td>
                                            </tr>
                                            <tr>
                                                <td>4</td>
                                                <td><strong class="text-white">French Football League</strong></td>
                                                <td>22</td>
                                                <td>3</td>
                                                <td>2</td>
                                                <td>140</td>
                                            </tr>
                                            <tr>
                                                <td>5</td>
                                                <td><strong class="text-white">Legia Abante</strong></td>
                                                <td>22</td>
                                                <td>3</td>
                                                <td>2</td>
                                                <td>140</td>
                                            </tr>
                                            <tr>
                                                <td>6</td>
                                                <td><strong class="text-white">Gliwice League</strong></td>
                                                <td>22</td>
                                                <td>3</td>
                                                <td>2</td>
                                                <td>140</td>
                                            </tr>
                                            <tr>
                                                <td>7</td>
                                                <td><strong class="text-white">Cornika</strong></td>
                                                <td>22</td>
                                                <td>3</td>
                                                <td>2</td>
                                                <td>140</td>
                                            </tr>
                                            <tr>
                                                <td>8</td>
                                                <td><strong class="text-white">Gravity Smash</strong></td>
                                                <td>22</td>
                                                <td>3</td>
                                                <td>2</td>
                                                <td>140</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>

                <div className="site-section">
                    <div className="container">
                        <Row align="middle" justify="space-between">
                            <Col span={12} className="title-section">
                                <h2 className="heading">Videos</h2>
                            </Col>
                            <Col span={12} className="text-right">
                                {/* Add custom navigation here */}
                            </Col>
                        </Row>

                        <Carousel className="owl-4-slider">
                            {videos.map((video, index) => (
                                <div className="item" key={index}>
                                    <div className="video-media">
                                        <img src={video.thumbnail} alt="Image" className="img-fluid" />
                                        <a href={video.videoUrl} className="d-flex play-button align-items-center" data-fancybox>
                                            <span className="icon mr-3">
                                                <PlayCircleOutlined />
                                            </span>
                                            <div className="caption">
                                                <h3 className="m-0">{video.title}</h3>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            ))}
                        </Carousel>
                    </div>
                </div>

                <div class="container site-section">
                    <div class="row">
                        <div class="col-6 title-section">
                            <h2 class="heading">Our Blog</h2>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="custom-media d-flex">
                                <div class="img mr-4">
                                    <img src="images/img_1.jpg" alt="Image" class="img-fluid" />
                                </div>
                                <div class="text">
                                    <span class="meta">May 20, 2020</span>
                                    <h3 class="mb-4"><a href="#">Romolu to stay at Real Nadrid?</a></h3>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Possimus deserunt saepe tempora dolorem.</p>
                                    <p><a href="#">Read more</a></p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="custom-media d-flex">
                                <div class="img mr-4">
                                    <img src="images/img_3.jpg" alt="Image" class="img-fluid" />
                                </div>
                                <div class="text">
                                    <span class="meta">May 20, 2020</span>
                                    <h3 class="mb-4"><a href="#">Romolu to stay at Real Nadrid?</a></h3>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Possimus deserunt saepe tempora dolorem.</p>
                                    <p><a href="#">Read more</a></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>



                <footer class="footer-section">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-3">
                                <div class="widget mb-3">
                                    <h3>News</h3>
                                    <ul class="list-unstyled links">
                                        <li><a href="#">All</a></li>
                                        <li><a href="#">Club News</a></li>
                                        <li><a href="#">Media Center</a></li>
                                        <li><a href="#">Video</a></li>
                                        <li><a href="#">RSS</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-lg-3">
                                <div class="widget mb-3">
                                    <h3>Tickets</h3>
                                    <ul class="list-unstyled links">
                                        <li><a href="#">Online Ticket</a></li>
                                        <li><a href="#">Payment and Prices</a></li>
                                        <li><a href="#">Contact &amp; Booking</a></li>
                                        <li><a href="#">Tickets</a></li>
                                        <li><a href="#">Coupon</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-lg-3">
                                <div class="widget mb-3">
                                    <h3>Matches</h3>
                                    <ul class="list-unstyled links">
                                        <li><a href="#">Standings</a></li>
                                        <li><a href="#">World Cup</a></li>
                                        <li><a href="#">La Lega</a></li>
                                        <li><a href="#">Hyper Cup</a></li>
                                        <li><a href="#">World League</a></li>
                                    </ul>
                                </div>
                            </div>

                            <div class="col-lg-3">
                                <div class="widget mb-3">
                                    <h3>Social</h3>
                                    <ul class="list-unstyled links">
                                        <li><a href="#">Twitter</a></li>
                                        <li><a href="#">Facebook</a></li>
                                        <li><a href="#">Instagram</a></li>
                                        <li><a href="#">Youtube</a></li>
                                    </ul>
                                </div>
                            </div>

                        </div>

                        <div class="row text-center">
                            <div class="col-md-12">
                                <div class=" pt-5">
                                    <p>

                                        Copyright &copy;
                                        <script>
                                            document.write(new Date().getFullYear());
                                        </script> All rights reserved | This template is made with <i class="icon-heart"
                                            aria-hidden="true"></i> by <a href="https://colorlib.com/" target="_blank">Colorlib</a>

                                    </p>
                                </div>
                            </div>

                        </div>
                    </div>
                </footer>

            </div>
        </div>
    )
}

export default Home
